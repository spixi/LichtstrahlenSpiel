package de.bwvaachen.beamoflightgame.logic.solver;

public class SolverFactory {
	public ISolver factory() {
		DependencySolver ds = new DependencySolver();
		
		
	}

}
