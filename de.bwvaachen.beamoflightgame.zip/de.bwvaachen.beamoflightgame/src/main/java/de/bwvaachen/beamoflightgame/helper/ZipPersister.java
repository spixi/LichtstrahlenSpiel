package de.bwvaachen.beamoflightgame.helper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Savepoint;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import de.bwvaachen.beamoflightgame.controller.Turn;
import de.bwvaachen.beamoflightgame.model.IBeamsOfLightPuzzleBoard;

public class ZipPersister implements IPersistenceHelper {

	private ICodec codec;

	public ZipPersister(ICodec saveCodec) {
		this.codec = saveCodec;
	}

	@Override
	public void save(File path, IBeamsOfLightPuzzleBoard board, List<Turn> turns)
			throws IOException {
		
		FileOutputStream fileOutputStream = new FileOutputStream(path);
		ZipOutputStream zipOut = new ZipOutputStream(fileOutputStream);
		try{

		zipOut.putNextEntry(new ZipEntry("codec"));
		zipOut.write(codec.getClass().toString().getBytes());

		zipOut.putNextEntry(new ZipEntry("board"));
		

		zipOut.putNextEntry(new ZipEntry("turns"));

		zipOut.flush();
		fileOutputStream.flush();
		}catch(Throwable t){
			zipOut.close();
			fileOutputStream.close();
			throw t;
		}

	}

	@Override
	public void load(File path) throws IOException {
		FileInputStream fileInputStream=new FileInputStream(path);
		ZipInputStream zipIn=new ZipInputStream(fileInputStream);
		ZipEntry entry = zipIn.getNextEntry();
		while(entry!=null){
			
			entry = zipIn.getNextEntry();
		}
	}
	public static void main(String[] args) {
		ZipPersister test=new ZipPersister(new SimpleASCIICodec());
		try {
			test.save(new File("Test"), null, null);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
