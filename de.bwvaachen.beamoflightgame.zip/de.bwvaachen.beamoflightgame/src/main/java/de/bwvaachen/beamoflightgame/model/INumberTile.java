package de.bwvaachen.beamoflightgame.model;

public interface INumberTile extends ITile {
	public int getNumber();

}
