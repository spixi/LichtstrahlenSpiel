package de.bwvaachen.beamoflightgame.helper;

public class WrongCodecException extends Exception {

	public WrongCodecException(
			ArrayIndexOutOfBoundsException outOfBoundsException) {
		super(outOfBoundsException);
	}
	public WrongCodecException() {
		// TODO Auto-generated constructor stub
	}
	public WrongCodecException(String message) {
		super(message);
	}
	

}
