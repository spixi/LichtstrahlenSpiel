LichtstrahlenSpiel
==================
